#!/bin/bash

# Script de teste local para Dashboard de Metas
# Execute: bash test_local.sh

echo "=========================================="
echo "🧪 Teste Local - Dashboard de Metas"
echo "=========================================="
echo ""

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar Python
echo -n "1. Verificando Python... "
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "${GREEN}✓${NC} $PYTHON_VERSION"
else
    echo -e "${RED}✗${NC} Python 3 não encontrado!"
    echo "   Instale: sudo apt install python3"
    exit 1
fi

# Verificar pip
echo -n "2. Verificando pip... "
if command -v pip3 &> /dev/null; then
    echo -e "${GREEN}✓${NC} $(pip3 --version)"
else
    echo -e "${RED}✗${NC} pip3 não encontrado!"
    exit 1
fi

# Instalar dependências
echo "3. Instalando dependências..."
pip3 install -r requirements.txt --quiet
if [ $? -eq 0 ]; then
    echo -e "   ${GREEN}✓${NC} Dependências instaladas"
else
    echo -e "   ${RED}✗${NC} Erro ao instalar dependências"
    exit 1
fi

# Verificar estrutura de pastas
echo -n "4. Verificando estrutura... "
if [ -d "data" ] && [ -d "docs" ] && [ -d ".github/workflows" ]; then
    echo -e "${GREEN}✓${NC} Estrutura OK"
else
    echo -e "${YELLOW}⚠${NC} Criando pastas faltantes..."
    mkdir -p data docs .github/workflows
fi

# Verificar arquivo de dados
echo -n "5. Verificando dados... "
if [ -f "data/metas_atual.json" ]; then
    echo -e "${GREEN}✓${NC} Arquivo de dados existe"
else
    echo -e "${YELLOW}⚠${NC} Arquivo de dados não encontrado"
    echo "   Será criado após primeira execução"
fi

# Testar geração do dashboard
echo "6. Gerando dashboard de teste..."
python3 generate_dashboard.py
if [ $? -eq 0 ] && [ -f "docs/index.html" ]; then
    echo -e "   ${GREEN}✓${NC} Dashboard gerado com sucesso!"
else
    echo -e "   ${RED}✗${NC} Erro ao gerar dashboard"
    exit 1
fi

# Verificar tamanho do HTML
HTML_SIZE=$(wc -c < docs/index.html)
echo "   Tamanho do HTML: ${HTML_SIZE} bytes"

# Resumo
echo ""
echo "=========================================="
echo "📊 Resumo do Teste"
echo "=========================================="
echo -e "${GREEN}✓${NC} Python instalado"
echo -e "${GREEN}✓${NC} Dependências OK"
echo -e "${GREEN}✓${NC} Estrutura de pastas OK"
echo -e "${GREEN}✓${NC} Dashboard gerado"
echo ""
echo "🌐 Para visualizar localmente:"
echo "   cd docs && python3 -m http.server 8000"
echo "   Depois acesse: http://localhost:8000"
echo ""
echo "🚀 Próximo passo:"
echo "   Siga o arquivo SETUP.md para configurar no GitHub"
echo ""
echo "=========================================="
echo -e "${GREEN}✅ Teste concluído com sucesso!${NC}"
echo "=========================================="
